﻿namespace _03DefineAnInterfaceIPerson
{
    public interface IPerson
    {
        string Name { get; }
        
        int Age { get; }
    }
}
