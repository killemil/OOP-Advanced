﻿namespace _04MultipleImplementation.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
