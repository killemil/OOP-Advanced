﻿namespace _04MultipleImplementation.Models
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
