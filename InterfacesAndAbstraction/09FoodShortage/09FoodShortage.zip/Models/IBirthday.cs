﻿
namespace _09FoodShortage.Models
{
    using System;

    public interface IBirthday
    {
        DateTime BirthDay { get; }
    }
}
