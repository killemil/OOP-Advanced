﻿namespace _09FoodShortage.Models
{
    public interface IMachine
    {
        string Model { get; }
    }
}
