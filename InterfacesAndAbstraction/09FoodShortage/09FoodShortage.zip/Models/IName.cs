﻿namespace _09FoodShortage.Models
{
    public interface IName
    {
        string Name { get; }
    }
}
