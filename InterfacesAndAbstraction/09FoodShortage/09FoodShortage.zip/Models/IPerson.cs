﻿namespace _09FoodShortage.Models
{
    public interface IPerson
    {
        int Age { get; }
    }
}
