﻿namespace _06Telephony
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}
