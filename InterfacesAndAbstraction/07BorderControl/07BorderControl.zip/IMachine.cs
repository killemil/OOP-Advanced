﻿namespace _07BorderControl
{
    public interface IMachine
    {
        string Model { get; }
    }
}
