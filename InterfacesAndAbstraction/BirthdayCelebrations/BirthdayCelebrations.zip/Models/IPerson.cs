﻿namespace BirthdayCelebrations
{
    public interface IPerson
    {
        int Age { get; }
    }
}
