﻿namespace BirthdayCelebrations
{
    public interface IMachine
    {
        string Model { get; }
    }
}
