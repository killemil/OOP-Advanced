﻿
namespace BirthdayCelebrations
{
    using System;

    public interface IBirthday
    {
        DateTime BirthDay { get; }
    }
}
