﻿namespace _10MilitaryElite.Intefaces
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}
