﻿namespace _10MilitaryElite.Intefaces
{
    public interface IRepair
    {
        string PartName { get; }
        int HoursWorked { get; }
    }
}
