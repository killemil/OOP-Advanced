﻿namespace _10MilitaryElite.Intefaces
{
    public interface ISpecialisedSoldier 
    {
        string Corps { get; }
    }
}
