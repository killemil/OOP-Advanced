﻿namespace _10MilitaryElite.Intefaces
{
    public interface IPrivate 
    {
        double Salary { get; }
    }
}
