﻿namespace _08DeckOfCards
{
    public enum Suit
    {
        Clubs,
        Hearts,
        Diamonds,
        Spades
    }
}
