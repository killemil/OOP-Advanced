﻿namespace _02HarvestingFields
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Numerics;
    using System.Text;
    using System.Threading;

    public class RichSoilLand
    {
        private Int32 testInt;
        public Double testDouble;
        protected String testString;
        private Int64 testLong;
        protected Double aDouble;
        public String aString;
        private Calendar aCalendar;
        public StringBuilder aBuilder;
        private Char testChar;
        public Int16 testShort;
        protected Byte testByte;
        public Byte aByte;
        protected StringBuilder aBuffer;
        private BigInteger testBigInt;
        protected BigInteger testBigNumber;
        protected Single testFloat;
        public Single aFloat;
        private Thread aThread;
        public Thread testThread;
        private Object aPredicate;
        protected Object testPredicate;
        public Object anObject;
        private Object hiddenObject;
        protected Object fatherMotherObject;
        private String anotherString;
        protected String moarString;
        public Int32 anotherIntBitesTheDust;
        private Exception internalException;
        protected Exception inheritableException;
        public Exception justException;
        public Stream aStream;
        protected Stream moarStreamz;
        private Stream secretStream;

    }
}
