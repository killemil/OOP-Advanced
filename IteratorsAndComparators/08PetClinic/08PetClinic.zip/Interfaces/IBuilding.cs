﻿namespace _08PetClinic.Interfaces
{
    public interface IBuilding
    {
        string Name { get; }

        int Rooms { get; }
    }
}
