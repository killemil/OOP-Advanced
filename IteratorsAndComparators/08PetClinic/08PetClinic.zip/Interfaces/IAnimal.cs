﻿namespace _08PetClinic.Interfaces
{
    public interface IAnimal
    {
        string Name { get; }

        int Age { get; }

        string Kind { get; }
    }
}
